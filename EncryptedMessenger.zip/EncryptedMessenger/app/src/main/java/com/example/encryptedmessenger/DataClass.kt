package com.example.encryptedmessenger

data class DataClass(var dataName:String, var userID: String)
