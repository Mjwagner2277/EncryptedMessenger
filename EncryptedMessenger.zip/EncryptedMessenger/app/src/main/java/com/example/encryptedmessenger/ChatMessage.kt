package com.example.encryptedmessenger

import java.util.Date

data class ChatMessage(val senderName: String?, val message: String, val timestamp: Date)

